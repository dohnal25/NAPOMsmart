<?php

	$sess = "mysql:host=127.0.0.1;port=3306;dbname=dohnal25";
	$name = "dohnal25";
	$pass = "Tis*5733501";

	try{
		$conn = new PDO($sess, $name, $pass,
						array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
						PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
	}catch(PDOException $ex){
		die($ex->getMessage());
	}


?>