<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/addArticle_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		} 
	?>
	<div id='mainPart'>
		<?php
			$query = $conn->prepare("SELECT * FROM nh_articles WHERE id = ? AND article_author_id = ? AND article_state = 'REJECTED'");
			$query->execute(array($_GET['article_id'], $_SESSION['logged']));	
			if($query->rowCount() <= 0) {
				header("Location: ./index.php");
			} else {
				while($row = $query->fetch()) {
					$article_name = $row['article_name'];
					$article_text = $row['article_text'];
					$article_cat = $row['article_category'];
				}
			}
		?>
		<span id='addArticleFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='addArticleError'></p>
			<table>
				<tr>
					<td colspan="2">Název článku:</td>
				</tr>
				<tr>
					<td colspan="2"><input type='text' id='articleName' value='<?php if(isset($article_name)) echo $article_name;?>'/></td>
				</tr>
				<tr>
					<td colspan="2">Kategorie:</td>
				</tr>
				<tr>
					<td colspan="2">						
						<select name="category" id="category">
							<option value="science" <?php if($article_cat == "science") echo "selected";?>>Vědecké</option>
						  	<option value="interesting" <?php if($article_cat == "interesting") echo "selected";?>>Zajímavosti</option>
						  	<option value="school" <?php if($article_cat == "school") echo "selected";?>>Škola</option>
						  	<option value="erotic" <?php if($article_cat == "erotic") echo "selected";?>>Erotické</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2">Text článku:</td>
				</tr>
				<tr>
					<td>
						<textarea id='articleText'><?php if(isset($article_name)) echo $article_text;?></textarea>
					</td>
				</tr>
				<tr>
					<td><button onclick='addArticle();'>Editovat článek</button></td>
				</tr>
			</table>
		</center>
	</div>

</body>

<script type="text/javascript">
	function addArticle() {
		let articleError = document.getElementById('addArticleError');
		let articleName = document.getElementById('articleName').value;
		let articleText = document.getElementById('articleText').value;
		let articleCategory = document.getElementById('category').value;
		let articleId = "<?php echo $_GET['article_id']; ?>";

		if(articleName.trim() != "") {
			if(articleText.trim() != "") {

				$.ajax({
					url:"editArticleScript.php",
					method:"post",
					data:{
						articleName: articleName,
						articleText: articleText,
						articleCategory: articleCategory,
						articleId: articleId
					},
					dataType:"text",
					success:function(data){
						if($.trim(data) === 'OK') {
							articleError.style.color = 'green';
							articleError.innerHTML = 'Článek byl předán redakci.';
						} else {
							articleError.innerHTML = data;
						}
					}
				});

			} else {
				articleError.innerHTML = "Vyplňte prosím text článku.";
			}
		} else {
			articleError.innerHTML = "Vyplňte prosím název článku.";
		}
	}
</script>

</html>

<?php
	ob_end_flush();
?>