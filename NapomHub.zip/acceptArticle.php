<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/acceptArticle_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		} 
	?>
	<div id='mainPart'>
		<?php
			$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_users ON article_author_id = user_id WHERE id = ? AND editor_id = ?");
			$query->execute(array($_GET['article_id'], $_SESSION['logged']));	
			if($query->rowCount() <= 0) {
				header("Location: ./index.php");
			}

		?>
		<span id='addArticleFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='addArticleError'></p>
			<table>
				<?php
					try {
					$query = $conn->prepare("SELECT * FROM nh_articles LEFT JOIN nh_reviews ON article_id = id WHERE id = ?");
					$query->execute(array($_GET['article_id']));
					}catch(PDOException $ex){}

					if($query->rowCount() >= 1) {
						while($row = $query->fetch()) {
							$article_name = $row['article_name'];
							$article_category = $row['article_category'];
							$article_text = $row['article_text'];
							$article_state = $row['article_state'];
							$review_state = $row['review_state'];
							$review_answer = $row['review_answer'];
							$reviewer_id = $row['reviewer_id'];
							$benefit = $row['benefit'];
							$originality = $row['originality'];
							$professionalism = $row['professionalism'];
							$language = $row['language'];
							$article_author_id = $row['article_author_id'];
						}
					} else {
						die("<center>Chyba při zobrazování článku.</center>");
					}
					if($article_state != "PASSED_TO_REVIEW" && $article_state != "PUBLISHED") {
						if(isset($review_state)) {
							if($review_state == "TO_BE_REVIEWED" || ($review_state == "REJECTED" && ($article_state == "WRITTEN" || $article_state == "REJECTED"))) {
								$canEdit = true;
							}
						} else {
							$canEdit = true;
						}
					}

					if(isset($review_state) && isset($review_state) != NULL) {
						$changeReviewer = false;
					} else {
						$changeReviewer = true;
					}
				?>
				<tr>
					<td colspan="2">Název článku:</td>
				</tr>
				<tr>
					<td colspan="2"><input type='text' id='articleName' value=<?php echo "'" . $article_name . "'"; ?> <?php if(!$canEdit) echo "disabled";?>></td>
				</tr>
				<tr>
					<td colspan="2">Kategorie:</td>
				</tr>
				<tr>
					<td colspan="2">						
						<select name="category" id="category" <?php if(!$canEdit) echo "disabled";?>>
							<option value="science"<?php if($article_category == "science") echo " selected";?>>Vědecké</option>
						  	<option value="interesting"<?php if($article_category == "interesting") echo " selected";?>>Zajímavosti</option>
						  	<option value="school"<?php if($article_category == "school") echo " selected";?>>Škola</option>
						  	<option value="erotic"<?php if($article_category == "erotic") echo " selected";?>>Erotické</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2">Text článku:</td>
				</tr>
				<tr>
					<td>
						<textarea id='articleText' <?php if(!$canEdit) echo "disabled";?>><?php echo $article_text; ?></textarea>
					</td>
				</tr>
				<tr>
					<td>
						Recenzent:
					</td>
				</tr>
				<tr>
					<td>
						<select name="reviewers" id="reviewers" <?php if(!$canEdit || !$changeReviewer) echo "disabled";?>>
							<?php
								try {
								$query = $conn->prepare("SELECT * FROM nh_users WHERE role = 'REVIEWER' AND user_id != ?");
								$query->execute(array($article_author_id));
								}catch(PDOException $ex){}

								if($query->rowCount() >= 1) {
									while($row = $query->fetch()) {
										$article_name = $row['article_name'];
										$article_category = $row['article_category'];
										$article_text = $row['article_text'];
										$sel = "";
										if($reviewer_id == $row['user_id']) {
											$sel = "selected";
										} 
										echo "<option $sel value=" . $row['user_id'] . ">" . $row['user_id'] . " - " . $row['user_name'] . "</option>";
										$canPublish = true;
									}
								} else {
									echo"<option>Žádný recenzent k zobrazení.</option>";
									$canPublish = false;
								}
							?>
						</select>
					</td>
				</tr>
				<?php
					if(isset($review_state)) {
						if($review_state != "TO_BE_REVIEWED") {
							echo "<tr><td>Hodnocení recenzenta:</td></tr>";
							echo "<tr><td><textarea disabled>" . $review_answer . "</textarea></td></tr>";
							echo "<tr><td>Aktuálnost, zajímavost a přínosnost (1 nejlepší, 5 nejhorší): $benefit</td></tr>";
							echo "<tr><td>Originalita (1 nejlepší, 5 nejhorší): $originality</td></tr>";
							echo "<tr><td>Odborná úroveň (1 nejlepší, 5 nejhorší): $professionalism</td></tr>";
							echo "<tr><td>Jazyková a stylistická úroveň (1 nejlepší, 5 nejhorší): $language</td></tr>";
						}
					}
				?>
				<tr>
					<?php
						if($canEdit) {
							?>
							<td style="display: flex; justify-content: space-between;"><button id='publishButton' <?php if($canPublish) echo "onclick='sendArticleToReview();'"; else echo "onclick='noReviewers();'";?>>Publikovat článek</button>
							<button id='rejectButton' onclick='rejectArticle();' style='background: red;'>Zamítnout</button></td>
							<?php
						}
					?>
				</tr>
			</table>
		</center>
	</div>

</body>

<script type="text/javascript">
	function noReviewers() {
		let articleError = document.getElementById('addArticleError');
		articleError.innerHTML = "Žádný recenzent není k dispozici.";
	}

	function sendArticleToReview() {
		let articleError = document.getElementById('addArticleError');
		let articleId = "<?php echo $_GET['article_id']; ?>";
		let articleName = document.getElementById('articleName').value;
		let articleText = document.getElementById('articleText').value;
		let articleCategory = document.getElementById('category').value;
		let articleReviewerId = document.getElementById('reviewers').value;
		let publishButton = document.getElementById('publishButton');
		let rejectButton = document.getElementById('rejectButton');

		if(articleName.trim() != "") {
			if(articleText.trim() != "") {
				$.ajax({
					url:"sendArticleToReviewScript.php",
					method:"post",
					data:{
						articleName: articleName,
						articleText: articleText,
						articleCategory: articleCategory,
						articleId: articleId,
						articleReviewerId: articleReviewerId
					},
					dataType:"text",
					success:function(data){
						if($.trim(data) === 'OK') {
							articleError.style.color = 'green';
							articleError.innerHTML = 'Článek byl předán k recenznímu řízení.';
							publishButton.disabled = true;
							rejectButton.disabled = true;
						} else {
							articleError.innerHTML = data;
						}
					}
				});

			} else {
				articleError.innerHTML = "Vyplňte prosím text článku.";
			}
		} else {
			articleError.innerHTML = "Vyplňte prosím název článku.";
		}
	}


	function rejectArticle() {
		let articleError = document.getElementById('addArticleError');
		let articleId = "<?php echo $_GET['article_id']; ?>";
		$.ajax({
			url:"rejectArticleScript.php",
			method:"post",
			data:{
				articleId: articleId
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) === 'OK') {
					articleError.style.color = 'green';
					articleError.innerHTML = 'Článek byl zamítnut.';
				} else {
					articleError.innerHTML = data;
				}
			}
		});
	}
</script>

</html>

<?php
	ob_end_flush();
?>