<?php
	session_start();
	require_once('./connect2DB.php');

	$articleId = $_POST['articleId'];

	try {
		$query = $conn->prepare("UPDATE nh_articles SET article_state = 'REJECTED' WHERE id = ?");
		if($query->execute(array($articleId))) {
			echo "OK";
		} else {
			echo "Při zamítání článku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

