<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>

	<div id='mainPart'>
		<div id='articles'>

			<?php
				if(isset($_GET['page_num'])) {
					$page = trim($_GET['page_num']);	
				} else {
					$page = 1;
				}

				if(isset($_GET['search_query'])) {
					$searchQuery = "" . trim($_GET['search_query']) . "";	
				} else {
					$searchQuery = "";
				}

				$searchQuery = strtolower($searchQuery);
				
				try {
				$limit = ($page - 1) * 8;


				$serverversion = $conn->getAttribute(PDO::ATTR_SERVER_VERSION);
				$emulate_prepares_below_version = '5.1.17';
    			$emulate_prepares = (version_compare($serverversion, $emulate_prepares_below_version, '<'));
				$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, $emulate_prepares);
				$query = $conn->prepare("SELECT * FROM nh_articles WHERE LOWER(article_text) LIKE ? OR LOWER(article_name) LIKE ? LIMIT ?, 8");
				$query->execute(array("%$searchQuery%", "%$searchQuery%", $limit));
				}catch(PDOException $ex){}

				if($query->rowCount() >= 1) {
					while($row = $query->fetch()) {
						$aId = $row['id'];
						echo "<a href='./articleDetail.php?article_id=$aId'><span class='article'>";
						echo "<span class='articleImage'><img src='./images/avatar.png' alt='artImage' /></span>";
						echo "<span class='articleText'>";
						echo "<span class='articleName'>" . $row['article_name'] . "</span>";
						echo "<span class='articleViews'>" . ($row['article_views']) . " K zobrazení</span>";
						$article_txt = substr($row['article_text'], 0, 26);
						echo "<span class='articleDesc'>" . $article_txt . " ...</span>";
						echo "</span>";
						echo "</span></a>";
					}
				} else {
					echo("<center>Žádné články nebyly nalezeny.</center>");
				}
			?>

		</div>
		<div id='commercials'>
			<span id='commercialWide'>
				<img src='./images/commercialWide.png' alt='commercialWide' />
			</span>
			<span id='commercialSquare'>
				<img src='./images/commercialSquare.png' alt='commercialSquare' />
			</span>
		</div>
		<div id='pageBar'>
			<?php
				if(isset($_GET['page_num'])) {
					if($_GET['page_num'] > 1) {
						$prev_page = $_GET['page_num'] - 1;
					} else {
						$prev_page = $_GET['page_num'];
					}
				} else {
					$prev_page = 1;
				}

				if(isset($_GET['search_query'])) {
					$searchQueryP = "&search_query=" . trim($_GET['search_query']);	
				} else {
					$searchQueryP = "";
				}

				echo "<a class='pageEdge' href='?page_num=$prev_page" . "$searchQueryP'><</a>";
			?>
			<?php
				$query = $conn->prepare("SELECT COUNT(*) FROM nh_articles WHERE LOWER(article_text) LIKE ? OR LOWER(article_name) LIKE ?");
				$query->execute(array("%$searchQuery%", "%$searchQuery%"));

				$count = $query->fetchColumn();
				if(isset($_GET['search_query'])) {
					$searchQueryP = "&search_query=" . trim($_GET['search_query']);	
				} else {
					$searchQueryP = "";
				}

				for($i = 0; $i < $count/8; $i++) {
					$page = $i+1;
					echo "<a class='page' href='?page_num=$page" . $searchQueryP . "'>" . $page . "</a>";
				}

				$page = $page+1;

				if($count % 8 != 0 && (($page - 1) * 8) < $count) {
					 echo "<a class='page' href='?page_num=$page" . $searchQueryP . "'>" . ($page) . "</a>";
				}
			?>
			<?php
				if(isset($_GET['page_num'])) {
					if(($_GET['page_num'] * 8) < $count) {	
						$next_page = $_GET['page_num'] + 1;
					} else {
						if(($count - ($_GET['page_num'] * 8)) % 8 != 0) {
							$next_page = $_GET['page_num'];
						} else {
							$next_page = $_GET['page_num'] + 1;
						}
					}
				} else {
					if($count % 8 != 0 && $count > ($page-1) * 8) {
						$next_page = 2;	
					} else {
						$next_page = 1;	
					}
				}

				if(isset($_GET['search_query'])) {
					$searchQueryP = "&search_query=" . trim($_GET['search_query']);	
				} else {
					$searchQueryP = "";
				}

				echo "<a class='pageEdge' href='?page_num=$next_page" . $searchQueryP . "'>></a>";
			?>
		</div>
	</div>
	
		
</body>

<script src="./logregScript.js"></script>

</html>

<?php
	ob_end_flush();
?>