<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/notify_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		}
	?>
	<div id='mainPart'>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
		<div class='notification'>
			<span class='text'>Váš článek "Studentka pomohla spolužák dostat kredity zadarmo" byl publikován.</span>
			<span class='time'>před 2 dny</span>
		</div>
	</div>

</body>


<?php
	ob_end_flush();
?>