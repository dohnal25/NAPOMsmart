<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/acceptArticle_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		} 
	?>
	<div id='mainPart'>
		<?php
			$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_reviews ON article_id = id WHERE article_id = ? AND reviewer_id = ?");
			$query->execute(array($_GET['article_id'], $_SESSION['logged']));	
			if($query->rowCount() <= 0) {
				header("Location: ./index.php");
			}
		?>

		<span id='addArticleFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='reviewArticleError'></p>
			<table>
				<?php
					try {
					$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_reviews ON article_id = id WHERE id = ?");
					$query->execute(array($_GET['article_id']));
					}catch(PDOException $ex){}

					if($query->rowCount() >= 1) {
						while($row = $query->fetch()) {
							$article_name = $row['article_name'];
							$article_category = $row['article_category'];
							$article_text = $row['article_text'];	
							$slider1Val = $row['benefit'];
							$slider2Val = $row['originality'];
							$slider3Val = $row['professionalism'];
							$slider4Val = $row['language'];
							$reviewAnswer = $row['review_answer'];
							$articleState = $row['review_state'];
						}
					} else {
						die("<center>Chyba při zobrazování článku.</center>");
					}
					if($articleState == "ACCEPTED") {
						$canEdit = false;
					} else {
						$canEdit = true;
					}
				?>
				<tr>
					<td colspan="2">Název článku:</td>
				</tr>
				<tr>
					<td colspan="2"><input disabled type='text' id='articleName' value=<?php echo "'" . $article_name . "'"; ?>></td>
				</tr>
				<tr>
					<td colspan="2">Kategorie:</td>
				</tr>
				<tr>
					<td colspan="2">						
						<select name="category" id="category" disabled>
							<option value="science"<?php if($article_category == "science") echo " selected";?>>Vědecké</option>
						  	<option value="interesting"<?php if($article_category == "interesting") echo " selected";?>>Zajímavosti</option>
						  	<option value="school"<?php if($article_category == "school") echo " selected";?>>Škola</option>
						  	<option value="erotic"<?php if($article_category == "erotic") echo " selected";?>>Erotické</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2">Text článku:</td>
				</tr>
				<tr>
					<td>
						<textarea id='articleText' disabled><?php echo $article_text; ?></textarea>
					</td>
				</tr>
				<tr>
					<td>
						Aktuálnost, zajímavost a přínosnost (1 nejlepší, 5 nejhorší):
					</td>
				</tr>
				<tr>
					<td>
						<input type="range" id='slider1' min="1" max="5" value='<?php echo $slider1Val; ?>' oninput="slider1Val.innerHTML=this.value" <?php if(!$canEdit) echo "disabled";?>><span id='slider1Val'><?php echo $slider1Val; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Originalita (1 nejlepší, 5 nejhorší):
					</td>
				</tr>
				<tr>
					<td>
						<input type="range" id='slider2' min="1" max="5" value='<?php echo $slider2Val; ?>' oninput="slider2Val.innerHTML=this.value" <?php if(!$canEdit) echo "disabled";?>><span id='slider2Val'><?php echo $slider2Val; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Odborná úroveň (1 nejlepší, 5 nejhorší):
					</td>
				</tr>
				<tr>
					<td>
						<input type="range" id='slider3' min="1" max="5" value='<?php echo $slider3Val; ?>' oninput="slider3Val.innerHTML=this.value" <?php if(!$canEdit) echo "disabled";?>><span id='slider3Val'><?php echo $slider3Val; ?></span>
					</td>
				</tr>
				<tr>
					<td>
						Jazyková a stylistická úroveň (1 nejlepší, 5 nejhorší):
					</td>
				</tr>
				<tr>
					<td>
						<input type="range" id='slider4' min="1" max="5" value='<?php echo $slider4Val; ?>' oninput="slider4Val.innerHTML=this.value" <?php if(!$canEdit) echo "disabled";?>><span id='slider4Val'><?php echo $slider4Val; ?></span>
					</td>
				</tr>
				<tr>
					<td colspan="2">Otevřená odpověď:</td>
				</tr>
				<tr>
					<td>
						<textarea id='reviewAnswer' <?php if(!$canEdit) echo "disabled";?>><?php echo $reviewAnswer; ?></textarea>
					</td>
				</tr>
				<tr>
					<?php if($canEdit) { ?>
						<td style="display: flex; justify-content: space-between;"><button id='publishButton' onclick='acceptArticleReview();'>Schválit článek</button>
						<button id='rejectButton' onclick='rejectArticleReview();' style='background: red;'>Zamítnout</button></td>
					<?php } ?>
				</tr>
			</table>
		</center>
	</div>

</body>

<script type="text/javascript">

	function acceptArticleReview() {
		let articleError = document.getElementById('reviewArticleError');
		let articleId = "<?php echo $_GET['article_id']; ?>";
		let benefit = document.getElementById('slider1').value;
		let originality = document.getElementById('slider2').value;
		let professionalism = document.getElementById('slider3').value;
		let language = document.getElementById('slider4').value;
		let reviewAnswer = document.getElementById('reviewAnswer').value;
		
		let publishButton = document.getElementById('publishButton');
		let rejectButton = document.getElementById('rejectButton');

		$.ajax({
			url:"acceptArticleReviewScript.php",
			method:"post",
			data:{
				benefit: benefit,
				originality: originality,
				professionalism: professionalism,
				articleId: articleId,
				language: language,
				reviewAnswer: reviewAnswer
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) === 'OK') {
					articleError.style.color = 'green';
					articleError.innerHTML = 'Článek byl publikován.';

					publishButton.disabled = true;
					rejectButton.disabled = true;
				} else {
					articleError.innerHTML = data;
				}
			}
		});
	}


	function rejectArticleReview() {
		let articleError = document.getElementById('reviewArticleError');
		let articleId = "<?php echo $_GET['article_id']; ?>";
		let benefit = document.getElementById('slider1').value;
		let originality = document.getElementById('slider2').value;
		let professionalism = document.getElementById('slider3').value;
		let language = document.getElementById('slider4').value;
		let reviewAnswer = document.getElementById('reviewAnswer').value;
		
		let publishButton = document.getElementById('publishButton');
		let rejectButton = document.getElementById('rejectButton');

		$.ajax({
			url:"rejectArticleReviewScript.php",
			method:"post",
			data:{
				benefit: benefit,
				originality: originality,
				professionalism: professionalism,
				articleId: articleId,
				language: language,
				reviewAnswer: reviewAnswer
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) === 'OK') {
					articleError.style.color = 'green';
					articleError.innerHTML = 'Článek byl zamítnut.';

					publishButton.disabled = true;
					rejectButton.disabled = true;
				} else {
					articleError.innerHTML = data;
				}
			}
		});
	}
</script>

</html>

<?php
	ob_end_flush();
?>