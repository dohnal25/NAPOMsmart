<?php
	session_start();
	require_once('./connect2DB.php');

	$articleName = $_POST['articleName'];
	$articleText = $_POST['articleText'];
	$articleCategory = $_POST['articleCategory'];
	$articleId = $_POST['articleId'];
	$articleReviewerId = $_POST['articleReviewerId'];

	str_replace("/\n/g", "\\n", $articleText);

	try {
		$query = $conn->prepare("UPDATE nh_articles SET article_name = ?, article_text = ?, article_category = ?, article_state = 'PASSED_TO_REVIEW' WHERE id = ?");
		if($query->execute(array($articleName, $articleText, $articleCategory, $articleId))) {
			$query = $conn->prepare("SELECT * FROM nh_reviews WHERE article_id = ?");
			$query->execute(array($articleId));
			if($query->rowCount() <= 0) {
				$query = $conn->prepare("INSERT INTO nh_reviews VALUES(NULL, ?, ?, 'TO_BE_REVIEWED', 3, 3, 3, 3, NULL,CURRENT_TIMESTAMP);");
				if($query->execute(array($articleId, $articleReviewerId))) {
					echo "OK";
				}
			} else {
				echo "OK";
			}
		} else {
			echo "Při publikaci článku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

