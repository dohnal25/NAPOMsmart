<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/articleDetail_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>

	<div id='mainPart'>

		<?php
			try {
			$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_users ON article_author_id = user_id WHERE id = ?");
			$query->execute(array($_GET['article_id']));
			}catch(PDOException $ex){}

			if($query->rowCount() >= 1) {
				$query_vi = $conn->prepare("UPDATE nh_articles SET article_views = article_views+1 WHERE id = ?");
				$query_vi->execute(array($_GET['article_id']));
				while($row = $query->fetch()) {
					$article_text = str_replace(array("\r", "\n"), '', $row['article_text']);
					$article_name = $row['article_name'];
					$author_name = $row['user_name'];
					$author_id = $row['user_id'];
					$article_cat = $row['article_category'];
				}
			} else {
				die("<center>Článek nenalezen.</center>");
			}
		?>

		<div id='articlePart'>
			<div id='article'>
				<div id='articleWindow'>
					<video id='videoIntro' style='display: none; width: 100%; height: 100%; position: relative;'>
						<source src="./images/intro.mp4" type="video/mp4">
					</video>
					<center id='playButton' style='display:flex; align-items: center; justify-content: center;'><i onclick='playArticle();' class="fa fa-play-circle" aria-hidden="true" style='font-size: 50px; top:180px; position: relative;'></i></center>
				</div>
				<div id='articleName'>
					<?php echo $article_name; ?>
				</div>
			</div>
			<div id='commercialTall'>
				<img src='./images/commercialTall.gif' alt='commercialTall' />
			</div>
			<div id='authorProfile'>
				<a href='./profileDetail?profile_id=<?php echo $author_id; ?>'>
				<span id='authorProfileCard'>
					<span id='authorProfilePic'>
						<img src='./images/avatar.png' alt='authorProfilePic' />
					</span>
					<span id='authorProfileDets'>
						<span id='authorProfileName'>
							<?php echo $author_name; ?>
						</span>
						<span id='authorProfileArticlesCount'>
							<?php
								try {
								$query = $conn->prepare("SELECT COUNT(*) FROM nh_articles WHERE article_author_id = ?");
								$query->execute(array($author_id));
								}catch(PDOException $ex){}

								echo $query->rowCount() . " články";
							?>
						</span>
					</span>
				</span>	
				</a>
			</div>
		</div>
		<div id='recommandedArticlesPart'>
			<?php
				try {
				$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_users ON article_author_id = user_id WHERE article_author_id = ? OR article_category = ? LIMIT 4");
				$query->execute(array($author_id, $article_cat));
				}catch(PDOException $ex){}

				if($query->rowCount() >= 1) {
					while($row = $query->fetch()) {
						echo "<a href='./articleDetail.php?article_id=" . $row['id'] . "'>";
						echo "<span class='article'>";
						echo "<span class='articleImage'><img src='./images/avatar.png' alt='artImage' /></span>";
						echo "<span class='articleText'>";
						echo "<span class='articleName'>" . $row['article_name'] . "</span>";
						echo "<span class='articleViews'>" . ($row['article_views'])  ." K zobrazení</span>";
						$article_txt = substr($row['article_text'], 0, 26);
						echo "<span class='articleDesc'>" . $article_txt . "...</span>";
						echo "</span>";
						echo "</span>";
						echo "</a>";
					}
				} else {
					echo("<center>Žádné doporučené články nenalezeny.</center>");
				}
			?>
		</div>
		<div id='comments' style='padding-bottom: 60px; position:relative; display: block;'>
			<span id='addComment'>
				<?php
					$query = $conn->prepare("SELECT COUNT(*) FROM nh_comments WHERE article_id = ?");
					$query->execute(array($_GET['article_id']));
				?>
				<span id='commentsHeader'>Všechny komentáře (<?php echo $query->fetchColumn(); ?>)</span><br/>
				<?php
					if(isset($_SESSION['logged'])) {
						echo "<span id='addCommentLink'><a onclick='addComment();'>Napsat komentář</a></span>";
					} else {
						echo "<span id='loginRegisterAlert'><a onclick='showLogin();'>Přihlaste se</a> nebo <a onclick='showRegister();'>se registrujte</a> abyste mohli komentovat!</span>";
					}

				?>
			
			</span>
			<span id='commentsView'>
				<?php
					try {
					$query = $conn->prepare("SELECT * FROM nh_comments JOIN nh_users ON commentator_id = user_id WHERE article_id = ? AND reply_to = 0");
					$query->execute(array($_GET['article_id']));
					}catch(PDOException $ex){}

					if($query->rowCount() >= 1) {
						while($row = $query->fetch()) {
							echo "<span class='comment'>";
							$pId = $row['user_id'];
							echo "<a href='./profileDetail.php?profile_id=$pId'><span class='commentProfile'>";
							echo "<span class='profilePic'>";
							echo "<img src='./images/avatar.png' alt='artImage' />";
							echo "</span>";
							echo "<span class='profileDets'>";
							echo "<span class='profileUserName'>";
							echo $row['user_name'];
							echo "</span>";
							echo "<span class='profileArticlesCount'>";
							$query_cnt = $conn->prepare("SELECT COUNT(*) FROM nh_articles WHERE article_state = 'PUBLISHED' AND article_author_id = ?");
							$query_cnt->execute(array($row['user_id']));
							echo $query_cnt->fetchColumn() . " články";
							echo "</span>";
							echo "</span>";
							echo "</span></a>";

							echo "<span class='commentBody'>";
							echo $row['comment_text'];
							echo "</span>";
							echo "<span class='commentActions'>";
							echo "<ul>";
							
							$query_cnt = $conn->prepare("SELECT COUNT(*) FROM nh_comments_rating WHERE rating = 1 AND id_comment = ?");
							$query_cnt->execute(array($row['comment_id']));

							$query_cnt_d = $conn->prepare("SELECT COUNT(*) FROM nh_comments_rating WHERE rating = -1 AND id_comment = ?");
							$query_cnt_d->execute(array($row['comment_id']));

							echo "<li onclick='likeComment(this, " . $row['comment_id'] . ");'>" . $query_cnt->fetchColumn() . " like</li>";
							echo "<li onclick='dislikeComment(this, " . $row['comment_id'] . ");'>" . $query_cnt_d->fetchColumn()  . " dislike</li>";


							$query_cnt = $conn->prepare("SELECT COUNT(*) FROM nh_comments WHERE parent_comment = ?");
							$query_cnt->execute(array($row['comment_id']));
							echo "<li onclick='addReply(" . $row['comment_id'] . ", " . $row['comment_id'] . ");'>odpovědět (" . $query_cnt->fetchColumn() . " replies)</li>";
							echo "</ul>";
							echo "</span>";
							echo "</span>";

							//Replies
							try {
							$query_comm = $conn->prepare("SELECT * FROM nh_comments JOIN nh_users ON commentator_id = user_id WHERE article_id = ? AND parent_comment = ?");
							$query_comm->execute(array($_GET['article_id'], $row['comment_id']));
							}catch(PDOException $ex){}

							if($query_comm->rowCount() >= 1) {
								while($row_comm = $query_comm->fetch()) {
									echo "<span class='comment response'>";
									$pId = $row_comm['user_id'];
									echo "<a href='./profileDetail.php?profile_id=$pId'><span class='commentProfile'>";
									echo "<span class='profilePic'>";
									echo "<img src='./images/avatar.png' alt='artImage' />";
									echo "</span>";
									echo "<span class='profileDets'>";
									echo "<span class='profileUserName'>";
									echo $row_comm['user_name'];
									echo "</span>";
									echo "<span class='profileArticlesCount'>";
									$query_cnt = $conn->prepare("SELECT COUNT(*) FROM nh_articles WHERE article_state = 'PUBLISHED' AND article_author_id = ?");
									$query_cnt->execute(array($row_comm['user_id']));
									echo $query_cnt->fetchColumn() . " články";
									echo "</span>";
									echo "</span>";
									echo "</span></a>";

									$query_rep = $conn->prepare("SELECT user_name FROM nh_comments JOIN nh_users ON user_id = commentator_id WHERE comment_id = ?");
									$query_rep->execute(array($row_comm['reply_to']));

									echo "<span class='commentBody'>";
									echo "<span class='replyTo'>@" . $query_rep->fetchColumn() . " </span>" . $row_comm['comment_text'];
									echo "</span>";
									echo "<span class='commentActions'>";
									echo "<ul>";

									$query_cnt = $conn->prepare("SELECT COUNT(*) FROM nh_comments_rating WHERE rating = 1 AND id_comment = ?");
									$query_cnt->execute(array($row_comm['comment_id']));

									$query_cnt_d = $conn->prepare("SELECT COUNT(*) FROM nh_comments_rating WHERE rating = -1 AND id_comment = ?");
									$query_cnt_d->execute(array($row_comm['comment_id']));

									echo "<li onclick='likeComment(this, " . $row_comm['comment_id'] . ");'>" . $query_cnt->fetchColumn() . " like</li>";
									echo "<li onclick='dislikeComment(this, " . $row_comm['comment_id'] . ");'>" . $query_cnt_d->fetchColumn()  . " dislike</li>";
									echo "<li onclick='addReply(" . $row_comm['comment_id'] . ", " . $row['comment_id'] . ");'>odpovědět</li>";
									echo "</ul>";
									echo "</span>";
									echo "</span>";
								}
							}
						}
					} else {
						echo("<center>Článek zatím nikdo nekomentoval. Buďte první!</center>");
					}
				?>
			</span>
		</div>

	</div>
	
		
</body>

<script src="./logregScript.js"></script>
<script type="text/javascript">
	function playArticle() {
		document.getElementById('playButton').style.display = 'none';
		document.getElementById('videoIntro').style.display = 'block';
		document.getElementById('videoIntro').addEventListener('ended', myHandler, false);
	    function myHandler(e) {
	    	let article_text = '<?php echo $article_text; ?>';
	        document.getElementById('articleWindow').innerHTML = article_text;
	    }
		document.getElementById('videoIntro').play();
	}

	function addComment() {
		let commentText = prompt("Zadejte komentář:");
		let article_id = '<?php echo $_GET['article_id']; ?>';
		if (commentText != null && commentText.trim() != "") {
			$.ajax({
				url:"addCommentScript.php",
				method:"post",
				data:{
					article_id: article_id,
					commentText: commentText,
					reply_to: 0,
					parent_comment: 0
				},
				dataType:"text",
				success:function(data){
					if($.trim(data) === 'OK') {
						location.reload();
					} else {
						alert('Chyba při vkládání komentáře.');
					}
				}
			});
		} else {
			alert("Nelze vložit prázdný komentář.");
		}
	}

	function addReply(reply_to, parent_comment) {
		let commentText = prompt("Zadejte odpověď:");
		let article_id = '<?php echo $_GET['article_id']; ?>';
		if (commentText != null && commentText.trim() != "") {
			$.ajax({
				url:"addCommentScript.php",
				method:"post",
				data:{
					article_id: article_id,
					commentText: commentText,
					reply_to: reply_to,
					parent_comment: parent_comment
				},
				dataType:"text",
				success:function(data){
					if($.trim(data) === 'OK') {
						location.reload();
					} else {
						alert('Chyba při vkládání odpovědi.');
					}
				}
			});
		} else {
			alert("Nelze vložit prázdnou odpověď.");
		}
	}

	function likeComment(comment, comment_id) {
		$.ajax({
			url:"likeCommentScript.php",
			method:"post",
			data:{
				comment_id: comment_id
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) !== 'ERR') {
					comment.innerHTML = ((parseInt(comment.innerHTML.split(' ')[0]) + parseInt(data.split(';')[0])) + " like");

					let dislike = comment.parentNode.children[1];
					dislike.innerHTML = ((parseInt(dislike.innerHTML.split(' ')[0]) + parseInt(data.split(';')[1])) + " dislike");

				} else {
					alert('Chyba při hodnocení komentáře.');
				}
			}
		});
	}

	function dislikeComment(comment, comment_id) {
		$.ajax({
			url:"dislikeCommentScript.php",
			method:"post",
			data:{
				comment_id: comment_id
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) !== 'ERR') {
					comment.innerHTML = ((parseInt(comment.innerHTML.split(' ')[0]) + parseInt(data.split(';')[1])) + " dislike");
					
					let like = comment.parentNode.children[0];
					like.innerHTML = ((parseInt(like.innerHTML.split(' ')[0]) + parseInt(data.split(';')[0])) + " like");
				} else {
					alert('Chyba při hodnocení komentáře.');
				}
			}
		});
	}
</script>

</html>

<?php
	ob_end_flush();
?>