<?php
	session_start();
	require_once('./connect2DB.php');

	$articleName = $_POST['articleName'];
	$articleText = $_POST['articleText'];
	$articleCategory = $_POST['articleCategory'];
	$articleId = $_POST['articleId'];

	str_replace("/\n/g", "\\n", $articleText);

	try {
		$query = $conn->prepare("UPDATE nh_articles SET article_name = ?, article_text = ?, article_category = ?, article_state = 'WRITTEN' WHERE id = ?");
		if($query->execute(array($articleName, $articleText, $articleCategory, $articleId))) {
			echo "OK";
		} else {
			echo "Při editaci článku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

