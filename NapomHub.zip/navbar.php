<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div id='navbar'>
	<div id='topBar'>
		<span id='logo'>
			<img src='./images/logo.png' alt='logo' />
		</span>

		<span id='searchBar'>
			<?php
				if(isset($_GET['search_query'])) {
					$searchQuery = "" . trim($_GET['search_query']) . "";	
				} else {
					$searchQuery = "";
				}
			?>
			<input id='searchInput' type="text" value="<?php echo $searchQuery; ?>"/><button onclick='searchArticles();'>Hledat</button>
		</span>

		<span id='profileBar'>
			<?php
				if(!isset($_SESSION['logged'])) {
					echo "<a onclick='showLogin();'>Přihlásit se </a> | <a onclick='showRegister();'> Registrovat se</a>";
				} else {
					try {
						$query = $conn->prepare("SELECT * FROM nh_users WHERE user_id = ?");
						$query->execute(array($_SESSION['logged']));
					}catch(PDOException $ex){
						die($ex->getMessage());
					}

					if($query->rowCount() >= 1) {
						while($row = $query->fetch()) {
							echo "<i class='fa fa-power-off' aria-hidden='true' style='margin-right: 5px; cursor: pointer;' onclick='logOut();'></i>";
							echo "<a href='profileDetail.php?profile_id=" . $row['user_id'] . "'><span>";
							echo "<span id='profilePic'>";
								if($row['profile_pic'] == NULL) {
									$picPath = './images/avatar.png';
								} else {
									$picPath = $row['profile_pic'];
								}
								echo "<img src='" . $picPath . "' alt='profilePic' />";
							echo "</span>";
							echo "<span id='profileName'>";
								echo $row['user_name'];
							echo "</span>";
							echo "</span></a>";
							echo "<span id='notificationIcon'>";
								echo "<img src='./images/bell.png' alt='notIcon' />";
							echo "</span>";
							echo "<span id='messagessIcon'>";
								echo "<img src='./images/messagess.png' alt='notIcon' />";
							echo "</span>";
							$role = $row['role'];
						}
					} 
				}
			?>
		</span>
	</div>
	<div id='bottomBar'>
		<span id='userMenu'>
			<ul>
				<li><a href="./index.php">DOMŮ</a></li>
				<li>KATEGORIE</li>
				<li>CHAT</li>
			</ul>
		</span>

		<span id='authorMenu'>
			<ul>
				<?php
					if(isset($_SESSION['logged'])) {
						if($role == "EDITOR") {
							echo "<li><a href='./acceptArticles.php'>SCHVALOVÁNÍ ČLÁNKŮ</a></li>";
						}

						if($role == "REVIEWER") {
							echo "<li><a href='./reviewArticles.php'>RECENZOVÁNÍ ČLÁNKŮ</a></li>";
						}
						if($role != "USER") echo "<li><a href='./addArticle.php'>PŘIDÁNÍ ČLÁNKU</a></li>";
					}
				?>
			</ul>
		</span>
	</div>
</div>

<script type="text/javascript">
	function logOut() {
		$.ajax({
			url:"logoutScript.php",
			method:"post",
			data:{},
			dataType:"text",
			success:function(data){
				location.reload();
			}
		});
	}

	function searchArticles() {
		let page_num = '<?php echo $_GET['page_num']; ?>';
		let search_query = document.getElementById('searchInput').value;
		window.location.href = "./index.php?search_query=" + search_query;
	}
</script>