<?php
	require_once('./connect2DB.php');

	$regUserName = $_POST['regUserName'];
	$regPass = $_POST['regPass'];
	$regEmail = $_POST['regEmail'];

	try {
		$query = $conn->prepare("SELECT * FROM nh_users WHERE user_name = ?");
		$query->execute(array($regUserName));				
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

	if($query->rowCount() >= 1){
		echo "USER_EXISTS";
	} else {
		try {
			$query = $conn->prepare("INSERT INTO nh_users VALUES (NULL, ?, ?, ?, NULL, NULL, NULL, 'USER', 0, CURRENT_TIMESTAMP)");
		}catch(PDOException $ex){
			echo "REG_ERROR";
		}

		if($query->execute(array($regUserName, hash("sha512", $regPass), $regEmail))) {
			echo "OK";
		} else {
			echo "REG_ERROR";
		}
	}
/*
while($row = $query->fetch()) {
}
*/
?>

