<?php
	session_start();
	require_once('./connect2DB.php');

	$benefit = $_POST['benefit'];
	$originality = $_POST['originality'];
	$professionalism = $_POST['professionalism'];
	$articleId = $_POST['articleId'];
	$language = $_POST['language'];
	$reviewAnswer = $_POST['reviewAnswer'];

	try {
		$query = $conn->prepare("UPDATE nh_articles SET article_state = 'REJECTED' WHERE id = ?");
		if($query->execute(array($articleId))) {
			$query = $conn->prepare("UPDATE nh_reviews SET review_state = 'REJECTED', benefit = ?, originality = ?, professionalism = ?, language = ?, review_answer = ?, timestamp = CURRENT_TIMESTAMP WHERE article_id = ?");
			if($query->execute(array($benefit, $originality, $professionalism, $language, $reviewAnswer, $articleId))) {
				echo "OK";
			}
		} else {
			echo "Při zamítání článku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

