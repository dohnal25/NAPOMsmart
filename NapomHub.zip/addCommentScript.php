<?php
	session_start();
	require_once('./connect2DB.php');

	$article_id = $_POST['article_id'];
	$commentText = $_POST['commentText'];
	$reply_to = $_POST['reply_to'];
	$parent_comment = $_POST['parent_comment'];

	try {
		$query = $conn->prepare("INSERT INTO nh_comments VALUES(NULL, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
		if($query->execute(array($article_id, $_SESSION['logged'], $commentText, $reply_to, $parent_comment))) {
			echo "OK";
		} else {
			echo "Chyba při vkládání komentáře.";
		}				
	}catch(PDOException $ex){
		die($ex->getMessage());
	}
?>

