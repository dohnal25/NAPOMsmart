<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/addArticle_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		} 
	?>
	<div id='mainPart'>
		<span id='addArticleFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='addArticleError'></p>
			<table>
				<tr>
					<td colspan="2">Název článku:</td>
				</tr>
				<tr>
					<td colspan="2"><input type='text' id='articleName' /></td>
				</tr>
				<tr>
					<td colspan="2">Kategorie:</td>
				</tr>
				<tr>
					<td colspan="2">						
						<select name="category" id="category">
							<option value="science" selected>Vědecké</option>
						  	<option value="interesting">Zajímavosti</option>
						  	<option value="school">Škola</option>
						  	<option value="erotic">Erotické</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2">Text článku:</td>
				</tr>
				<tr>
					<td>
						<textarea id='articleText'></textarea>
					</td>
				</tr>
				<tr>
					<td><button onclick='addArticle();'>Publikovat článek</button></td>
				</tr>
			</table>
		</center>
	</div>

</body>

<script type="text/javascript">
	function addArticle() {
		let articleError = document.getElementById('addArticleError');
		let articleName = document.getElementById('articleName').value;
		let articleText = document.getElementById('articleText').value;
		let articleCategory = document.getElementById('category').value;

		if(articleName.trim() != "") {
			if(articleText.trim() != "") {

				$.ajax({
					url:"addArticleScript.php",
					method:"post",
					data:{
						articleName: articleName,
						articleText: articleText,
						articleCategory: articleCategory
					},
					dataType:"text",
					success:function(data){
						if($.trim(data) === 'OK') {
							articleError.style.color = 'green';
							articleError.innerHTML = 'Článek byl předán redakci.';
							document.getElementById('articleName').value = "";
							document.getElementById('articleText').value = "";
						} else {
							articleError.innerHTML = data;
						}
					}
				});

			} else {
				articleError.innerHTML = "Vyplňte prosím text článku.";
			}
		} else {
			articleError.innerHTML = "Vyplňte prosím název článku.";
		}
	}
</script>

</html>

<?php
	ob_end_flush();
?>