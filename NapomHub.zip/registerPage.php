<div id='registerContainer'>
	<div id='close' onclick='closeRegister();'><img src='./images/cross.png' alt='closeForm' /></div>
	<div id='registerForm'>
		<span id='registerFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='regError'></p>
			<table>
				<tr>
					<td colspan="2">Uživatelské jméno</td>
				</tr>
				<tr>
					<td colspan="2"><input type='text' id='regUserName' /></td>
				</tr>
				<tr>
					<td colspan="2">Email</td>
				</tr>
				<tr>
					<td colspan="2"><input type='email' id='regEmail' /></td>
				</tr>
				<tr>
					<td colspan="2">Heslo</td>
				</tr>
				<tr>
					<td colspan="2"><input type='password' id='regPass' /></td>
				</tr>
				<tr>
					<td colspan="2">Heslo znovu</td>
				</tr>
				<tr>
					<td colspan="2"><input type='password' id='regPassAgain' /></td>
				</tr>
				<tr>
					<td><button onclick='registerUser();'>Registrovat se</button></td>
					<td class='alignRight' onclick='showLogin();closeRegister();'>Jsem registrovaný</td>
				</tr>
			</table>
		</center>
	</div>
</div>