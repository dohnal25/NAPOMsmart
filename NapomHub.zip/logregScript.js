function showLogin() {
	document.getElementById('loginContainer').style.display = 'block';
}

function showRegister() {
	document.getElementById('registerContainer').style.display = 'block';	
}

function closeLogin() {
	document.getElementById('loginContainer').style.display = 'none';	
}

function closeRegister() {
	document.getElementById('registerContainer').style.display = 'none';	
}

function validateEmail(email) {
	var re = /\S+@\S+\.\S+/;
  	return re.test(email);
}

function registerUser() {
	let regError = document.getElementById('regError');
	let regUserName = document.getElementById('regUserName').value;
	let regEmail = document.getElementById('regEmail').value;
	let regPass = document.getElementById('regPass').value;
	let regPassAgain = document.getElementById('regPassAgain').value;
	
	regError.style.color = 'red';

	if(regUserName.trim() != "") {
		if(regEmail.trim() != "") {
			if(regPass.trim() != "") {
				if(regPassAgain.trim() != "") {
					if(regPass == regPassAgain) {
						if(validateEmail(regEmail)) {
							//Checks if the username already exists/register the user
							$.ajax({
								url:"registerScript.php",
								method:"post",
								data:{
									regUserName: regUserName,
									regPass: regPass,
									regEmail, regEmail
								},
								dataType:"text",
								success:function(data){
									if($.trim(data) === 'USER_EXISTS') {
										regError.innerHTML = 'Toto uživatelské jméno je již obsazeno.';
									} else if($.trim(data) === 'OK') {
										regError.style.color = 'green';
										regError.innerHTML = 'Registrace proběhla úspěšně.';
									} else if($.trim(data) === 'REG_ERROR'){
										regError.innerHTML = 'Neznámá chyba při registraci.';
									}
								}
							});
						} else {
							regError.innerHTML = 'Formát Emailu je chybný.';				
						}
					} else {
						regError.innerHTML = 'Zadaná hesla se neshodují.';				
					}
				} else {
					regError.innerHTML = 'Zopakujte prosím heslo.';			
				}
			} else {
				regError.innerHTML = 'Vyplňte prosím heslo.';		
			}
		} else {
			regError.innerHTML = 'Vyplňte prosím Email.';	
		}
	} else {
		regError.innerHTML = 'Vyplňte prosím uživatelské jméno.';
	}
	
}

function loginUser() {
	let logError = document.getElementById('logError');
	let logUserName = document.getElementById('logUserName').value;
	let logPass = document.getElementById('logPass').value;

	if(logUserName.trim() != "") {
		if(logPass.trim() != "") {
			//Checks if user exists/data are ok, if so => login 
			$.ajax({
				url:"loginScript.php",
				method:"post",
				data:{
					logUserName: logUserName,
					logPass: logPass
				},
				dataType:"text",
				success:function(data){
					if($.trim(data) === 'USER_NOT_EXISTS') {
						logError.innerHTML = 'Takový uživatel neexistuje.';
					} else if($.trim(data) === 'OK') {
						location.reload();
					} else if($.trim(data) === 'LOG_ERROR') {
						logError.innerHTML = 'Neznámá chyba při přihlašování.';
					} else if($.trim(data) === 'WRONG_ERROR') {
						logError.innerHTML = 'Špatné jméno nebo heslo.';
					}
				}
			});
		} else {
			logError.innerHTML = 'Zadejte prosím heslo.';
		}
	} else {
		logError.innerHTML = 'Zadejte prosím uživatelské jméno.';
	}
}