<div id='loginContainer'>
	<div id='close' onclick='closeLogin();'><img src='./images/cross.png' alt='closeForm' /></div>
	<div id='loginForm'>
		<span id='loginFormLogo'>
			<center><img src='./images/logo.png' alt='logo' /></center>
		</span>
		<br/>
		<center>
			<p style='color: #f00;' id='logError'></p>
			<table>
				<tr>
					<td colspan="2">Uživatelské jméno</td>
				</tr>
				<tr>
					<td colspan="2"><input type='text' id='logUserName' /></td>
				</tr>
				<tr>
					<td colspan="2">Heslo</td>
				</tr>
				<tr>
					<td colspan="2"><input type='password' id='logPass' /></td>
				</tr>
				<tr>
					<td><button onclick='loginUser();'>Přihlásit se</button></td>
					<td class='alignRight' onclick='showRegister();closeLogin();'>Zegistrovat se</td>
				</tr>
			</table>
		</center>
	</div>
</div>