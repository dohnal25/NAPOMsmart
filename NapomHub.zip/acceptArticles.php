<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/accept_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>
	<?php
		if(!isset($_SESSION['logged'])) {
			header("Location: ./index.php");
		}
	?>
	<div id='mainPart'>
		<?php
			$query = $conn->prepare("SELECT * FROM nh_users WHERE user_id = ? AND role = 'EDITOR'");
			$query->execute(array($_SESSION['logged']));	
			if($query->rowCount() <= 0) {
				header("Location: ./index.php");
			}

			try {
				$query = $conn->prepare("SELECT * FROM nh_articles JOIN nh_users ON article_author_id = user_id LEFT JOIN nh_reviews ON article_id = id WHERE nh_users.editor_id = ?");
				$query->execute(array($_SESSION['logged']));
			}catch(PDOException $ex){}


			if($query->rowCount() >= 1) {
				while($row = $query->fetch()) {
					$now = time();
					$your_date = strtotime($row['date']);
					$datediff = $now - $your_date;

					echo"<a style='color: white;' href='./acceptArticle?article_id=" . $row['id'] . "'><div class='article'>";
					echo "<span class='text'>Článek \"" . $row['article_name'] . "\" autora " . $row['user_name'];

					if($row['article_state'] == "WRITTEN") {
						echo "<b> čeká na schválení.</b>";
					} else if ($row['article_state'] == "PASSED_TO_REVIEW") {
						if(isset($row['review_state'])) {
							if($row['review_state'] == "REJECTED") {
								echo "<b> předán k opravnému recenznímu řízení.</b>";
							} else {
								echo "<b> předán k recenznímu řízení.</b>";
							}
						} else {
							echo "<b> předán k recenznímu řízení.</b>";	
						}	
					} else if ($row['article_state'] == "PUBLISHED") {
						echo "<b> publikován.</b>";
					} else if($row['article_state'] == "REJECTED") {
						if(isset($row['review_state'])) {
							if($row['review_state'] == "REJECTED") {
								echo "<b> zamítnut recenzentem.</b>";
							} else {
								echo "<b> zamítnut redaktorem.</b>";
							}
						} else {
							echo "<b> zamítnut redaktorem.</b>";	
						}			
					}

					echo "</span>";
					echo "<span class='time'>před " . abs(round($datediff / (60 * 60 * 24))) . " dny</span>";
					echo "</div></a>";
				}
			} else {
				echo "<center>Žádné články k zobrazení.</center>";
			}
		?>
	</div>

</body>


<?php
	ob_end_flush();
?>