<?php
	session_start();
	require_once('./connect2DB.php');

	$profileDescText = htmlspecialchars($_POST['profileDescText']);

	try {
		$query = $conn->prepare("UPDATE nh_users SET description = ? WHERE user_id = ?");
		if($query->execute(array($profileDescText, $_SESSION['logged']))) {
			echo "OK";
		} else {
			echo "Při editaci popisku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

