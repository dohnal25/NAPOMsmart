<?php
	session_start();
	require_once('./connect2DB.php');

	$logUserName = $_POST['logUserName'];
	$logPass = $_POST['logPass'];

	try {
		$query = $conn->prepare("SELECT * FROM nh_users WHERE user_name = ?");
		$query->execute(array($logUserName));				
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

	if($query->rowCount() <= 0){
		echo "USER_NOT_EXISTS";
	} else {
		try {
			$query = $conn->prepare("SELECT * FROM nh_users WHERE user_name = ? AND password = ?");
			$query->execute(array($logUserName, hash("sha512", $logPass)));
		}catch(PDOException $ex){
			echo "LOG_ERROR";
		}


		if($query->rowCount() >= 1) {
			while($row = $query->fetch()) {
				$_SESSION['logged'] = $row['user_id'];
			}
			echo "OK";
		} else {
			echo "WRONG_ERROR";
		}
	}
?>

