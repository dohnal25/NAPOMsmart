<?php
	session_start();
	ob_start();
	require_once('./connect2DB.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>NapomHub</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="styles/main_style.css">
	<link rel="stylesheet" type="text/css" href="styles/profileDetail_style.css">
</head>
<body>
	<?php include('./navbar.php'); ?>

	<?php include('./loginPage.php') ?>
	<?php include('./registerPage.php') ?>

	<div id='mainPart'>
		<?php
			try {
			$query = $conn->prepare("SELECT * FROM nh_users WHERE user_id = ?");
			$query->execute(array($_GET['profile_id']));
			}catch(PDOException $ex){}

			if($query->rowCount() >= 1) {
				while($row = $query->fetch()) {
					$profile_name = $row['user_name'];
					$background_pic = $row['background_pic'];
					$profile_pic = $row['profile_pic'];
					$profileDesc = $row['description'];

					if($background_pic == NULL) $background_pic = './images/background.jpg';
					if($profile_pic == NULL) $profile_pic = './images/avatar.png';
					if($profileDesc == NULL) {
						if($_SESSION['logged'] == $_GET['profile_id']) {
							$profileDesc = "Napište něco o sobě.";
						} else {
							$profileDesc = "Uživatel o sobě neposkytl podrobnější informace.";
						}
					} 
				}
			} else {
				die("<center>Profil nenalezen.</center>");
			}


		?>
		<div id='profileHeader' style="background: url('<?php echo $background_pic; ?>'); background-repeat: no-repeat; background-position: center; ">
			<span id='profileImage'>
				<img src='<?php echo $profile_pic; ?>' alt='profileImage' />
			</span>
			<span id='profileName'>
				<?php echo $profile_name; ?>
			</span>
		</div>

		<div id='commercialTall'>
			<img src='./images/commercialTall.gif' alt='commercialTall' />
		</div>

		<div id='profilePart'>
			<div id='profileDescription'>
				<b>Více o:</b> <?php echo $profile_name; ?>
				<?php
					if($_SESSION['logged'] == $_GET['profile_id']) {
						echo "<p id='profileDescError' style='color: red;'></p>";
						echo "<p><textarea id='profileDescText'>" . $profileDesc . "</textarea></p>";
						echo "<button onclick='saveDescription();'>Uložit informace o mě</button>";
					} else {
						echo "<p>" . $profileDesc . "</p>";
					}
				?>
			</div>

			<?php
				$query = $conn->prepare("SELECT COUNT(*) FROM nh_articles WHERE article_author_id = ? AND article_state = 'PUBLISHED'");
				$query->execute(array($_GET['profile_id']));
				$cnt = $query->fetchColumn();
			?>
			<?php if($_GET['profile_id'] != $_SESSION['logged']) {?>

				<h3><?php echo $profile_name; ?> články (<?php echo $cnt; ?>)</h3><br/>
				<div id='profileArticles'>								
					<?php
						try {
							$query = $conn->prepare("SELECT * FROM nh_articles WHERE article_author_id = ?");
							$query->execute(array($_GET['profile_id']));
						}catch(PDOException $ex){}

						if($query->rowCount() >= 1) {
							while($row = $query->fetch()) {
								echo"<a style='color: #fff; text-decoration:none;' href=./articleDetail?article_id=" . $row['id'] . "><span class='article'>";
								echo"<span class='articleImage'><img src='./images/avatar.png' alt='artImage' /></span>";
								echo"<span class='articleText'>";
								echo"<span class='articleName'>" . $row['article_name'] . "</span>";
								echo"<span class='articleViews'>" . ($row['article_views'])  . " K zobrazení</span>";
								$article_txt = substr($row['article_text'], 0, 26);
								echo"<span class='articleDesc'>" . $article_txt . "...</span>";
								echo"</span>";
								echo"</span></a>";
							}
						} else {
							echo "<center>Uživatel zatím nenapsal žádné články.</center>";
						}
					?>
				</div>
			<?php } else { 
				echo "<h3>Vaše články:</h3>";	
				try {
					$query = $conn->prepare("SELECT * FROM nh_articles LEFT JOIN nh_reviews ON article_id = id WHERE article_author_id = ?");
					$query->execute(array($_SESSION['logged']));
				}catch(PDOException $ex){}


				if($query->rowCount() >= 1) {
					while($row = $query->fetch()) {
						$now = time();
						$your_date = strtotime($row['date']);
						$datediff = $now - $your_date;

						$aId = $row['id'];
						if ($row['article_state'] == "PUBLISHED") {
							$href = "href='articleDetail.php?article_id=$aId'";
						} else if ($row['article_state'] == "REJECTED") {
							$href = "href='editArticle.php?article_id=$aId'";
						} else {
							$href = "";
						}

						echo"<a style='color: white;' $href><div class='articleMy'>";
						echo "<span class='text'>Článek \"" . $row['article_name'] . "\"";

						if($row['article_state'] == "WRITTEN") {
							echo "<b> čeká na schválení.</b>";
						} else if ($row['article_state'] == "PASSED_TO_REVIEW") {
							if(isset($row['review_state'])) {
								if($row['review_state'] == "REJECTED") {
									echo "<b> předán k opravnému recenznímu řízení.</b>";
								} else {
									echo "<b> předán k recenznímu řízení.</b>";
								}
							} else {
								echo "<b> předán k recenznímu řízení.</b>";	
							}	
						} else if ($row['article_state'] == "PUBLISHED") {
							echo "<b> publikován.</b>";
						} else if($row['article_state'] == "REJECTED") {
							if(isset($row['review_state'])) {
								if($row['review_state'] == "REJECTED") {
									echo "<b> zamítnut recenzentem.</b>";
								} else {
									echo "<b> zamítnut redaktorem.</b>";
								}
							} else {
								echo "<b> zamítnut redaktorem.</b>";	
							}			
						}

						echo "</span>";
						echo "<span class='time'>před " . abs(round($datediff / (60 * 60 * 24))) . " dny</span>";
						echo "</div></a>";
					}
				} else {
					echo "<center>Nenapsali jste zatím žádné články.</center>";
				}

			}?>	
		</div>
		
	</div>
</body>

<script src="./logregScript.js"></script>
<script type="text/javascript">
	function saveDescription() {
		let profileDescText = document.getElementById('profileDescText').value;
		let profileDescError = document.getElementById('profileDescError');

		$.ajax({
			url:"editProfileDescScript.php",
			method:"post",
			data:{
				profileDescText: profileDescText
			},
			dataType:"text",
			success:function(data){
				if($.trim(data) === 'OK') {
					profileDescError.style.color = 'green';
					profileDescError.innerHTML = 'Informace o Vás byly editovány.';
				} else {
					profileDescError.style.color = 'red';
					profileDescError.innerHTML = 'Nebylo možné uložit popisek.';
				}
			}
		});
	}
</script>

</html>

<?php
	ob_end_flush();
?>