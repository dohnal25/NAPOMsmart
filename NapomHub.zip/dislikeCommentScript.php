<?php
	session_start();
	require_once('./connect2DB.php');

	$comment_id = $_POST['comment_id'];

	$query = $conn->prepare("SELECT * FROM nh_comments_rating WHERE id_user = ? AND id_comment = ?");
	$query->execute(array($_SESSION['logged'], $comment_id));

	if($query->rowCount() >= 1) {
		while($row = $query->fetch()) {
			if($row['rating'] == -1) {
				$query2 = $conn->prepare("DELETE FROM nh_comments_rating WHERE id_user = ? AND id_comment = ?");
				if($query2->execute(array($_SESSION['logged'], $comment_id))) {
					echo "0;-1";
				} else {
					echo "ERR";
				}
			} else {
				$query2 = $conn->prepare("UPDATE nh_comments_rating SET rating = -1 WHERE id_user = ? AND id_comment = ?");
				if($query2->execute(array($_SESSION['logged'], $comment_id))) {
					echo "-1;1";
				} else {
					echo "ERR";
				}
			}
		}
	} else {
		$query2 = $conn->prepare("INSERT INTO nh_comments_rating VALUES(NULL, ?, ?, -1)");
		if($query2->execute(array($_SESSION['logged'], $comment_id))) {
			echo "0;1";
		} else {
			echo "ERR";
		}
	}
	
?>

