<?php
	session_start();
	require_once('./connect2DB.php');

	$articleName = $_POST['articleName'];
	$articleText = $_POST['articleText'];
	$articleCategory = $_POST['articleCategory'];

	str_replace("/\n/g", "\\n", $articleText);

	try {
		$query = $conn->prepare("INSERT INTO nh_articles VALUES(NULL, ?, ?, ?, 0, ?, 'WRITTEN', CURRENT_TIMESTAMP)");
		if($query->execute(array($articleName, $articleText, $articleCategory, $_SESSION['logged']))) {
			echo "OK";
		} else {
			echo "Při publikaci článku se vyskytla chyba.";
		}			
	}catch(PDOException $ex){
		die($ex->getMessage());
	}

?>

